﻿using System;
using Microsoft.Maui.Controls;

namespace MarioGardening
{
    public partial class Page2 : ContentPage
    {
        public Page2()
        {
            InitializeComponent();
        }

        private async void OnAnteriorClicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }

        private async void OnSiguienteClicked(object sender, EventArgs e)
        {
            var producto = productoEntry.Text;
            var page3 = new Page3(producto);
            await Navigation.PushAsync(page3);
        }
    }
}