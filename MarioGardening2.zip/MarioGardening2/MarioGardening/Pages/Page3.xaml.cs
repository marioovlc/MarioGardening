﻿using System;
using Microsoft.Maui.Controls;

namespace MarioGardening
{
    public partial class Page3 : ContentPage
    {
        private string producto;

        public Page3(string producto)
        {
            InitializeComponent();
            this.producto = producto;
        }

        private async void OnAnteriorClicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }

        private async void OnSiguienteClicked(object sender, EventArgs e)
        {
            var unidades = unidadesEntry.Text;
            var page4 = new Page4(producto, unidades);
            await Navigation.PushAsync(page4);
        }
    }
}