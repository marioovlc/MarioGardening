﻿using System;
using Microsoft.Maui.Controls;

namespace MarioGardening
{
    public partial class Page4 : ContentPage
    {
        private string producto;
        private readonly string unidades;

        public Page4(string producto, string unidades)
        {
            InitializeComponent();
            this.producto = producto;
            this.unidades = unidades;
        }

        private async void OnAnteriorClicked(object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }

        private async void OnSiguienteClicked(object sender, EventArgs e)
        {
            var direccion = direccionEntry.Text;
            var page5 = new Page5(producto, unidades, direccion);
            await Navigation.PushAsync(page5);
        }
    }
}