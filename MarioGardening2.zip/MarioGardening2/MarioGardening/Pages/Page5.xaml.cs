﻿using System;
using Microsoft.Maui.Controls;

namespace MarioGardening
{
    public partial class Page5 : ContentPage
    {
        private string producto;
        private string unidades;
        private string direccion;

        public Page5(string producto, string unidades, string direccion)
        {
            InitializeComponent();
            this.producto = producto;
            this.unidades = unidades;
            this.direccion = direccion;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            resumenLabel.Text = $"Producto: {producto}, Unidades: {unidades}, Dirección: {direccion}";
        }

        private async void OnVolverClicked(object sender, EventArgs e)
        {
            // Navegar de vuelta a la MainPage
            await Navigation.PopToRootAsync();
        }
    }
}